# 🚚 ACME Pedidos - API REST de Abastecimiento

API REST desarrollada en **Spring Boot 3.2** para el ciclo de abastecimiento de la compañía ACME.
Actúa como puente entre la tienda carrera 70 (JSON) y el sistema de envío de pedidos (SOAP/XML).

---

## 📐 Arquitectura

```
Tienda Carrera 70
      │
      │ POST /api/pedidos/enviar
      │ (JSON)
      ▼
┌─────────────────┐
│  PedidoController│
└────────┬────────┘
         │
         ▼
┌─────────────────┐    XML SOAP    ┌─────────────────────────┐
│  PedidoService  │ ─────────────► │  Servicio Externo ACME  │
│  (Transforma    │ ◄───────────── │  (run.mocky.io)         │
│  JSON ↔ XML)    │    XML SOAP    └─────────────────────────┘
└────────┬────────┘
         │
         │ (JSON)
         ▼
    Respuesta al cliente
```

## 🔄 Transformaciones

### Request: JSON → XML SOAP

| REST (JSON)      | SOAP (XML)  |
|------------------|-------------|
| numPedido        | pedido      |
| cantidadPedido   | Cantidad    |
| codigoEAN        | EAN         |
| nombreProducto   | Producto    |
| numDocumento     | Cedula      |
| direccion        | Direccion   |

### Response: XML SOAP → JSON

| SOAP (XML) | REST (JSON)  |
|------------|--------------|
| Codigo     | codigoEnvio  |
| Mensaje    | estado       |

---

## 🚀 Ejecución

### Opción 1: Docker Compose (Recomendado)

```bash
# Clonar el repositorio
git clone <url-repositorio>
cd acme-pedidos

# Construir y levantar el contenedor
docker-compose up --build

# En segundo plano
docker-compose up --build -d
```

### Opción 2: Docker manual

```bash
# Build de la imagen
docker build -t acme-pedidos:1.0.0 .

# Ejecutar el contenedor
docker run -d \
  --name acme-pedidos-service \
  -p 8080:8080 \
  acme-pedidos:1.0.0
```

### Opción 3: Maven (local)

```bash
# Requiere Java 17 y Maven 3.9+
mvn clean package
java -jar target/acme-pedidos-1.0.0.jar
```

---

## 📡 Endpoints

| Método | URL                         | Descripción              |
|--------|-----------------------------|--------------------------|
| POST   | `/api/pedidos/enviar`       | Enviar pedido            |
| GET    | `/api/pedidos/health`       | Health check             |
| GET    | `/swagger-ui.html`          | Documentación Swagger UI |
| GET    | `/api-docs`                 | OpenAPI spec (JSON)      |

---

## 📋 Ejemplos de uso

### Request

```bash
curl -X POST http://localhost:8080/api/pedidos/enviar \
  -H "Content-Type: application/json" \
  -d '{
    "enviarPedido": {
      "numPedido": "75630275",
      "cantidadPedido": "1",
      "codigoEAN": "00110000765191002104587",
      "nombreProducto": "Armario INVAL",
      "numDocumento": "1113987400",
      "direccion": "CR 72B 45 12 APT 301"
    }
  }'
```

### Response

```json
{
  "enviarPedidoRespuesta": {
    "codigoEnvio": "80375472",
    "estado": "Entregado exitosamente al cliente"
  }
}
```

---

## 🛠 Tecnologías

- **Java 17**
- **Spring Boot 3.2.4**
- **RestTemplate** para llamadas HTTP al servicio externo
- **JAXP / DOM Parser** para procesamiento XML
- **Springdoc OpenAPI 2.5** (Swagger UI)
- **Lombok**
- **Docker & Docker Compose**
- **Maven**

---

## 📂 Estructura del Proyecto

```
acme-pedidos/
├── src/
│   └── main/
│       ├── java/com/acme/pedidos/
│       │   ├── AcmePedidosApplication.java   # Clase principal
│       │   ├── config/
│       │   │   └── AppConfig.java            # Configuración de beans
│       │   ├── controller/
│       │   │   └── PedidoController.java     # Controlador REST
│       │   ├── dto/
│       │   │   ├── EnviarPedidoRequest.java
│       │   │   ├── EnviarPedidoWrapper.java
│       │   │   ├── EnviarPedidoResponse.java
│       │   │   └── EnviarPedidoResponseWrapper.java
│       │   └── service/
│       │       └── PedidoService.java        # Lógica de negocio
│       └── resources/
│           └── application.properties
├── Dockerfile
├── docker-compose.yml
├── pom.xml
└── README.md
```

---

## 🔧 Variables de Entorno

| Variable            | Descripción                   | Valor por defecto                                     |
|---------------------|-------------------------------|-------------------------------------------------------|
| `ACME_SOAP_ENDPOINT`| URL del servicio SOAP externo | `https://run.mocky.io/v3/19217075-6d4e-4818-98bc-416d1feb7b84` |
| `SERVER_PORT`       | Puerto del servidor           | `8080`                                                |

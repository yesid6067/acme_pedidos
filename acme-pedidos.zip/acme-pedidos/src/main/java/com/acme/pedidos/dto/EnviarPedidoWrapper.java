package com.acme.pedidos.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * Wrapper del request JSON con la estructura { "enviarPedido": { ... } }
 */
@Data
public class EnviarPedidoWrapper {

    @JsonProperty("enviarPedido")
    private EnviarPedidoRequest enviarPedido;
}

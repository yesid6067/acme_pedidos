package com.acme.pedidos.controller;

import com.acme.pedidos.dto.EnviarPedidoResponseWrapper;
import com.acme.pedidos.dto.EnviarPedidoWrapper;
import com.acme.pedidos.service.PedidoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Controlador REST para el ciclo de abastecimiento de pedidos ACME.
 * Expone el endpoint para recibir pedidos en formato JSON desde la tienda carrera 70.
 */
@Slf4j
@RestController
@RequestMapping("/api/pedidos")
@RequiredArgsConstructor
@Tag(name = "Pedidos ACME", description = "API REST para el ciclo de abastecimiento de pedidos")
public class PedidoController {

    private final PedidoService pedidoService;

    /**
     * Endpoint principal para enviar un pedido.
     * Recibe JSON, llama al servicio SOAP con XML y retorna JSON.
     *
     * @param requestWrapper Wrapper con los datos del pedido en JSON
     * @return Respuesta con código de envío y estado en JSON
     */
    @PostMapping(
            value = "/enviar",
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE
    )
    @Operation(
            summary = "Enviar pedido al sistema de abastecimiento",
            description = """
                    Recibe un pedido en formato JSON, lo transforma a XML SOAP,
                    lo envía al servicio externo de EnvioPedidosAcme y retorna
                    la respuesta transformada de XML a JSON.
                    """,
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    required = true,
                    content = @Content(
                            mediaType = "application/json",
                            examples = @ExampleObject(
                                    name = "Ejemplo de pedido",
                                    value = """
                                            {
                                              "enviarPedido": {
                                                "numPedido": "75630275",
                                                "cantidadPedido": "1",
                                                "codigoEAN": "00110000765191002104587",
                                                "nombreProducto": "Armario INVAL",
                                                "numDocumento": "1113987400",
                                                "direccion": "CR 72B 45 12 APT 301"
                                              }
                                            }
                                            """
                            )
                    )
            ),
            responses = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "Pedido procesado exitosamente",
                            content = @Content(
                                    mediaType = "application/json",
                                    examples = @ExampleObject(
                                            value = """
                                                    {
                                                      "enviarPedidoRespuesta": {
                                                        "codigoEnvio": "80375472",
                                                        "estado": "Entregado exitosamente al cliente"
                                                      }
                                                    }
                                                    """
                                    )
                            )
                    ),
                    @ApiResponse(responseCode = "400", description = "Datos del pedido inválidos"),
                    @ApiResponse(responseCode = "500", description = "Error interno del servidor")
            }
    )
    public ResponseEntity<EnviarPedidoResponseWrapper> enviarPedido(@RequestBody EnviarPedidoWrapper requestWrapper) {
        log.info("Solicitud de envío de pedido recibida");

        if (requestWrapper == null || requestWrapper.getEnviarPedido() == null) {
            return ResponseEntity.badRequest().build();
        }

        EnviarPedidoResponseWrapper response = pedidoService.procesarPedido(requestWrapper.getEnviarPedido());
        return ResponseEntity.ok(response);
    }

    /**
     * Endpoint de health check para verificar que el servicio está activo.
     */
    @GetMapping("/health")
    @Operation(summary = "Health check", description = "Verifica que el servicio está activo")
    public ResponseEntity<String> health() {
        return ResponseEntity.ok("Servicio ACME Pedidos activo ✓");
    }
}

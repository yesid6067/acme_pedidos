package com.acme.pedidos.service;

import com.acme.pedidos.dto.EnviarPedidoRequest;
import com.acme.pedidos.dto.EnviarPedidoResponse;
import com.acme.pedidos.dto.EnviarPedidoResponseWrapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.StringReader;

/**
 * Servicio principal que orquesta:
 * 1. Transformación JSON → XML SOAP
 * 2. Llamada al servicio externo (mock)
 * 3. Transformación XML SOAP response → JSON
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class PedidoService {

    private final RestTemplate restTemplate;

    @Value("${acme.soap.endpoint:https://run.mocky.io/v3/19217075-6d4e-4818-98bc-416d1feb7b84}")
    private String soapEndpoint;

    /**
     * Procesa el pedido:
     * - Convierte el request JSON a XML SOAP
     * - Envía al endpoint externo
     * - Convierte la respuesta XML a JSON
     *
     * @param request DTO con los datos del pedido en formato JSON
     * @return DTO con la respuesta en formato JSON
     */
    public EnviarPedidoResponseWrapper procesarPedido(EnviarPedidoRequest request) {
        log.info("Procesando pedido: {}", request.getNumPedido());

        // Paso 1: Transformar JSON → XML SOAP
        String xmlRequest = construirSoapRequest(request);
        log.debug("XML SOAP generado:\n{}", xmlRequest);

        // Paso 2: Llamar al servicio externo con XML
        String xmlResponse = llamarServicioExterno(xmlRequest);
        log.debug("XML SOAP recibido:\n{}", xmlResponse);

        // Paso 3: Transformar XML response → JSON
        EnviarPedidoResponseWrapper response = parsearSoapResponse(xmlResponse);
        log.info("Respuesta procesada - codigoEnvio: {}", response.getEnviarPedidoRespuesta().getCodigoEnvio());

        return response;
    }

    /**
     * Construye el envelope SOAP a partir del DTO JSON.
     *
     * Mapeo JSON → XML:
     * numPedido       → pedido
     * cantidadPedido  → Cantidad
     * codigoEAN       → EAN
     * nombreProducto  → Producto
     * numDocumento    → Cedula
     * direccion       → Direccion
     */
    private String construirSoapRequest(EnviarPedidoRequest req) {
        return """
                <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
                                  xmlns:env="http://WSDLs/EnvioPedidos/EnvioPedidosAcme">
                    <soapenv:Header/>
                    <soapenv:Body>
                        <env:EnvioPedidoAcme>
                            <EnvioPedidoRequest>
                                <pedido>%s</pedido>
                                <Cantidad>%s</Cantidad>
                                <EAN>%s</EAN>
                                <Producto>%s</Producto>
                                <Cedula>%s</Cedula>
                                <Direccion>%s</Direccion>
                            </EnvioPedidoRequest>
                        </env:EnvioPedidoAcme>
                    </soapenv:Body>
                </soapenv:Envelope>
                """.formatted(
                req.getNumPedido(),
                req.getCantidadPedido(),
                req.getCodigoEAN(),
                req.getNombreProducto(),
                req.getNumDocumento(),
                req.getDireccion()
        );
    }

    /**
     * Realiza la llamada HTTP POST al endpoint externo enviando el XML SOAP.
     */
    private String llamarServicioExterno(String xmlBody) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.TEXT_XML);
        headers.set("SOAPAction", "EnvioPedidoAcme");

        HttpEntity<String> entity = new HttpEntity<>(xmlBody, headers);

        log.info("Llamando al endpoint: {}", soapEndpoint);
        ResponseEntity<String> response = restTemplate.exchange(
                soapEndpoint,
                HttpMethod.POST,
                entity,
                String.class
        );

        if (!response.getStatusCode().is2xxSuccessful()) {
            throw new RuntimeException("Error al llamar al servicio externo. Status: " + response.getStatusCode());
        }

        return response.getBody();
    }

    /**
     * Parsea la respuesta XML SOAP y la convierte al DTO JSON.
     *
     * Mapeo XML → JSON:
     * Codigo  → codigoEnvio
     * Mensaje → estado
     */
    private EnviarPedidoResponseWrapper parsearSoapResponse(String xmlResponse) {
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            factory.setNamespaceAware(true);
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = builder.parse(new InputSource(new StringReader(xmlResponse)));
            document.getDocumentElement().normalize();

            String codigoEnvio = obtenerValorTag(document, "Codigo");
            String estado = obtenerValorTag(document, "Mensaje");

            EnviarPedidoResponse pedidoResponse = new EnviarPedidoResponse(codigoEnvio, estado);
            return new EnviarPedidoResponseWrapper(pedidoResponse);

        } catch (Exception e) {
            log.error("Error al parsear la respuesta XML: {}", e.getMessage(), e);
            throw new RuntimeException("Error al procesar la respuesta del servicio externo", e);
        }
    }

    /**
     * Extrae el valor de texto de un tag XML por su nombre local.
     */
    private String obtenerValorTag(Document document, String tagName) {
        NodeList nodes = document.getElementsByTagNameNS("*", tagName);
        if (nodes.getLength() == 0) {
            // Intento sin namespace
            nodes = document.getElementsByTagName(tagName);
        }
        if (nodes.getLength() > 0) {
            return nodes.item(0).getTextContent().trim();
        }
        log.warn("Tag '{}' no encontrado en la respuesta XML", tagName);
        return "";
    }
}

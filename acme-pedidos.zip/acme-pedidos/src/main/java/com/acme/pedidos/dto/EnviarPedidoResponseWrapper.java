package com.acme.pedidos.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Wrapper de la respuesta JSON con la estructura { "enviarPedidoRespuesta": { ... } }
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class EnviarPedidoResponseWrapper {

    @JsonProperty("enviarPedidoRespuesta")
    private EnviarPedidoResponse enviarPedidoRespuesta;
}

package com.acme.pedidos.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DTO que representa la respuesta JSON devuelta por la API REST.
 * Mapeado desde la respuesta XML del servicio SOAP.
 *
 * Mapeo:
 * XML: Codigo  -> JSON: codigoEnvio
 * XML: Mensaje -> JSON: estado
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class EnviarPedidoResponse {

    @JsonProperty("codigoEnvio")
    private String codigoEnvio;

    @JsonProperty("estado")
    private String estado;
}

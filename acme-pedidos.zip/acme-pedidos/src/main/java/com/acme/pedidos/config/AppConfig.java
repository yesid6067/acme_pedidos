package com.acme.pedidos.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

/**
 * Configuración de beans de Spring para la aplicación.
 */
@Configuration
public class AppConfig {

    /**
     * Bean de RestTemplate para realizar llamadas HTTP al servicio externo.
     */
    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }
}

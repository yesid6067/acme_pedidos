package com.acme.pedidos.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * DTO que representa la petición JSON recibida por la API REST.
 * Contiene los datos del pedido enviados por la tienda carrera 70.
 */
@Data
public class EnviarPedidoRequest {

    @JsonProperty("numPedido")
    private String numPedido;

    @JsonProperty("cantidadPedido")
    private String cantidadPedido;

    @JsonProperty("codigoEAN")
    private String codigoEAN;

    @JsonProperty("nombreProducto")
    private String nombreProducto;

    @JsonProperty("numDocumento")
    private String numDocumento;

    @JsonProperty("direccion")
    private String direccion;
}

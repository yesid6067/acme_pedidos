import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: '<app-dna-detector></app-dna-detector>',
})
export class AppComponent {}

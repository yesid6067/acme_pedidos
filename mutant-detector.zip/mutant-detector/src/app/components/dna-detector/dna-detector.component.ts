import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MutantService, DnaAnalysisResult } from '../../services/mutant.service';

@Component({
  selector: 'app-dna-detector',
  templateUrl: './dna-detector.component.html',
  styleUrls: ['./dna-detector.component.scss']
})
export class DnaDetectorComponent implements OnInit {

  form!: FormGroup;
  result: DnaAnalysisResult | null = null;
  validationError: string | null = null;
  isAnalyzing = false;
  gridSize = 6;

  /** Casos de ejemplo precargados */
  readonly examples = [
    {
      label: '🧬 Mutante (ejemplo doc)',
      dna: ['ATGCGA', 'CAGTGC', 'TTATGT', 'AGAAGG', 'CCCCTA', 'TCACTG']
    },
    {
      label: '👤 Humano',
      dna: ['ATGCGA', 'CAGTGC', 'TTATTT', 'AGACGG', 'GCGTCA', 'TCACTG']
    },
    {
      label: '🧬 Mutante (vertical)',
      dna: ['ATGCGA', 'ATGTGC', 'ATTATG', 'ATAAGG', 'CCCCTA', 'TCACTG']
    }
  ];

  constructor(
    private fb: FormBuilder,
    public mutantService: MutantService
  ) {}

  ngOnInit(): void {
    this.buildForm(this.gridSize);
    this.loadExample(0); // Cargar ejemplo mutante por defecto
  }

  /** Construye el formulario reactivo con N filas */
  buildForm(n: number): void {
    const rows = Array.from({ length: n }, () =>
      this.fb.control('', [
        Validators.required,
        Validators.minLength(n),
        Validators.maxLength(n),
        Validators.pattern(/^[ATCGatcg]+$/)
      ])
    );

    this.form = this.fb.group({
      rows: this.fb.array(rows)
    });

    this.result = null;
    this.validationError = null;
  }

  get rowControls(): FormControl[] {
    return (this.form.get('rows') as FormArray).controls as FormControl[];
  }

  /** Cambia el tamaño de la matriz */
  changeSize(n: number): void {
    this.gridSize = n;
    this.buildForm(n);
  }

  /** Carga un ejemplo predefinido */
  loadExample(index: number): void {
    const example = this.examples[index];
    this.changeSize(example.dna.length);
    this.rowControls.forEach((ctrl, i) => ctrl.setValue(example.dna[i]));
    this.result = null;
  }

  /** Limpia el formulario */
  clear(): void {
    this.buildForm(this.gridSize);
  }

  /** Ejecuta el análisis de ADN */
  analyze(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    this.isAnalyzing = true;
    this.validationError = null;

    const dna: string[] = this.rowControls.map(c => (c.value as string).toUpperCase());

    // Validación de negocio
    const validation = this.mutantService.validateDna(dna);
    if (!validation.valid) {
      this.validationError = validation.error || 'ADN inválido';
      this.isAnalyzing = false;
      return;
    }

    // Simular procesamiento asíncrono (efecto visual)
    setTimeout(() => {
      this.result = this.mutantService.analyzeDna(dna);
      this.isAnalyzing = false;
    }, 800);
  }

  /** Retorna la clase CSS de una celda de la cuadrícula */
  getCellClass(row: number, col: number): string {
    if (!this.result) return '';
    return this.result.gridHighlights[row]?.[col] ? 'highlighted' : '';
  }

  /** Retorna el ícono según el tipo de secuencia */
  getSequenceIcon(type: string): string {
    const icons: Record<string, string> = {
      'horizontal': '→',
      'vertical': '↓',
      'diagonal-right': '↘',
      'diagonal-left': '↙'
    };
    return icons[type] || '?';
  }

  /** Retorna etiqueta en español del tipo de secuencia */
  getSequenceLabel(type: string): string {
    const labels: Record<string, string> = {
      'horizontal': 'Horizontal',
      'vertical': 'Vertical',
      'diagonal-right': 'Diagonal ↘',
      'diagonal-left': 'Diagonal ↙'
    };
    return labels[type] || type;
  }

  /** Array de tamaños disponibles para la matriz */
  get availableSizes(): number[] {
    return [4, 5, 6, 7, 8];
  }

  /** Obtiene el ADN actual como array de strings */
  get currentDna(): string[] {
    return this.rowControls.map(c => (c.value as string).toUpperCase());
  }
}

import { Injectable } from '@angular/core';

export interface DnaAnalysisResult {
  isMutant: boolean;
  sequences: FoundSequence[];
  totalSequences: number;
  gridHighlights: boolean[][];
}

export interface FoundSequence {
  type: 'horizontal' | 'vertical' | 'diagonal-right' | 'diagonal-left';
  positions: { row: number; col: number }[];
  letter: string;
}

/**
 * Servicio de detección de mutantes.
 *
 * Un humano es MUTANTE si su ADN contiene MÁS DE UNA secuencia
 * de cuatro letras iguales en horizontal, vertical u oblicua.
 *
 * Complejidad: O(n²) donde n es el tamaño de la matriz NxN.
 */
@Injectable({
  providedIn: 'root'
})
export class MutantService {

  private readonly SEQUENCE_LENGTH = 4;
  private readonly VALID_BASES = /^[ATCG]+$/;

  /**
   * Método principal de detección de mutante.
   * @param dna Array de strings que representan filas de la matriz NxN de ADN
   * @returns true si es mutante (más de 1 secuencia encontrada), false si es humano
   */
  isMutant(dna: string[]): boolean {
    const result = this.analyzeDna(dna);
    return result.isMutant;
  }

  /**
   * Análisis completo del ADN: detecta todas las secuencias y retorna detalle.
   * @param dna Array de strings con la secuencia de ADN
   * @returns Resultado detallado con secuencias encontradas y posiciones
   */
  analyzeDna(dna: string[]): DnaAnalysisResult {
    const n = dna.length;
    const sequences: FoundSequence[] = [];
    const gridHighlights: boolean[][] = Array.from({ length: n }, () =>
      Array(n).fill(false)
    );

    // Recorrer todas las direcciones posibles
    this.checkHorizontal(dna, n, sequences, gridHighlights);
    this.checkVertical(dna, n, sequences, gridHighlights);
    this.checkDiagonalRight(dna, n, sequences, gridHighlights);
    this.checkDiagonalLeft(dna, n, sequences, gridHighlights);

    return {
      isMutant: sequences.length > 1,
      sequences,
      totalSequences: sequences.length,
      gridHighlights
    };
  }

  /**
   * Verifica si el ADN ingresado es válido (NxN con letras A,T,C,G).
   */
  validateDna(dna: string[]): { valid: boolean; error?: string } {
    if (!dna || dna.length === 0) {
      return { valid: false, error: 'El ADN no puede estar vacío.' };
    }

    const n = dna.length;

    for (let i = 0; i < n; i++) {
      if (!dna[i] || dna[i].length !== n) {
        return {
          valid: false,
          error: `Fila ${i + 1}: debe tener exactamente ${n} caracteres (matriz NxN).`
        };
      }
      if (!this.VALID_BASES.test(dna[i].toUpperCase())) {
        return {
          valid: false,
          error: `Fila ${i + 1}: solo se permiten las letras A, T, C, G.`
        };
      }
    }

    return { valid: true };
  }

  // ─── Verificaciones por dirección ────────────────────────────────────────

  /** Busca secuencias horizontales de 4 letras iguales */
  private checkHorizontal(
    dna: string[], n: number,
    sequences: FoundSequence[], grid: boolean[][]
  ): void {
    for (let i = 0; i < n; i++) {
      for (let j = 0; j <= n - this.SEQUENCE_LENGTH; j++) {
        const ch = dna[i][j].toUpperCase();
        if (this.isSequence(dna[i][j], dna[i][j+1], dna[i][j+2], dna[i][j+3])) {
          const positions = [
            { row: i, col: j }, { row: i, col: j+1 },
            { row: i, col: j+2 }, { row: i, col: j+3 }
          ];
          sequences.push({ type: 'horizontal', positions, letter: ch });
          positions.forEach(p => grid[p.row][p.col] = true);
        }
      }
    }
  }

  /** Busca secuencias verticales de 4 letras iguales */
  private checkVertical(
    dna: string[], n: number,
    sequences: FoundSequence[], grid: boolean[][]
  ): void {
    for (let i = 0; i <= n - this.SEQUENCE_LENGTH; i++) {
      for (let j = 0; j < n; j++) {
        const ch = dna[i][j].toUpperCase();
        if (this.isSequence(dna[i][j], dna[i+1][j], dna[i+2][j], dna[i+3][j])) {
          const positions = [
            { row: i, col: j }, { row: i+1, col: j },
            { row: i+2, col: j }, { row: i+3, col: j }
          ];
          sequences.push({ type: 'vertical', positions, letter: ch });
          positions.forEach(p => grid[p.row][p.col] = true);
        }
      }
    }
  }

  /** Busca secuencias diagonales de izquierda a derecha (↘) */
  private checkDiagonalRight(
    dna: string[], n: number,
    sequences: FoundSequence[], grid: boolean[][]
  ): void {
    for (let i = 0; i <= n - this.SEQUENCE_LENGTH; i++) {
      for (let j = 0; j <= n - this.SEQUENCE_LENGTH; j++) {
        const ch = dna[i][j].toUpperCase();
        if (this.isSequence(dna[i][j], dna[i+1][j+1], dna[i+2][j+2], dna[i+3][j+3])) {
          const positions = [
            { row: i, col: j }, { row: i+1, col: j+1 },
            { row: i+2, col: j+2 }, { row: i+3, col: j+3 }
          ];
          sequences.push({ type: 'diagonal-right', positions, letter: ch });
          positions.forEach(p => grid[p.row][p.col] = true);
        }
      }
    }
  }

  /** Busca secuencias diagonales de derecha a izquierda (↙) */
  private checkDiagonalLeft(
    dna: string[], n: number,
    sequences: FoundSequence[], grid: boolean[][]
  ): void {
    for (let i = 0; i <= n - this.SEQUENCE_LENGTH; i++) {
      for (let j = this.SEQUENCE_LENGTH - 1; j < n; j++) {
        const ch = dna[i][j].toUpperCase();
        if (this.isSequence(dna[i][j], dna[i+1][j-1], dna[i+2][j-2], dna[i+3][j-3])) {
          const positions = [
            { row: i, col: j }, { row: i+1, col: j-1 },
            { row: i+2, col: j-2 }, { row: i+3, col: j-3 }
          ];
          sequences.push({ type: 'diagonal-left', positions, letter: ch });
          positions.forEach(p => grid[p.row][p.col] = true);
        }
      }
    }
  }

  /** Verifica si 4 caracteres son iguales */
  private isSequence(a: string, b: string, c: string, d: string): boolean {
    const upper = a.toUpperCase();
    return upper === b.toUpperCase() &&
           upper === c.toUpperCase() &&
           upper === d.toUpperCase();
  }
}

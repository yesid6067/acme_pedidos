# 🧬 Mutant Detector — X-Men DNA Analyzer

Aplicación Angular 17 que detecta si un humano es mutante basándose en su secuencia de ADN.

---

## 🔬 ¿Cómo funciona el algoritmo?

Un humano es **MUTANTE** si su ADN contiene **más de una** secuencia de cuatro letras iguales en:

| Dirección | Ejemplo |
|-----------|---------|
| ↔ Horizontal | `CCCC` en una fila |
| ↕ Vertical | `GGGG` en una columna |
| ↘ Diagonal (↘) | `AAAA` en diagonal izquierda→derecha |
| ↙ Diagonal (↙) | `TTTT` en diagonal derecha→izquierda |

### Ejemplo del documento:

```
ADN = ["ATGCGA","CAGTGC","TTATGT","AGAAGG","CCCCTA","TCACTG"]
```

```
A T G C G A
C A G T G C
T T A T G T   → TGAT diagonal ↘ con AAAA
A G A A G G   → AAAA horizontal
C C C C T A   → CCCC horizontal ✅
T C A C T G
```

**Resultado: `isMutant(dna) = true`** (2 secuencias encontradas)

### Complejidad del algoritmo:

- **Tiempo:** O(n²) — se recorre la matriz una sola vez por dirección
- **Espacio:** O(n²) — para el mapa de highlights de la cuadrícula

---

## 🚀 Ejecución

### Opción 1: Docker Compose (Recomendado)

```bash
git clone <url-repositorio>
cd mutant-detector

docker-compose up --build

# Acceder en: http://localhost:4200
```

### Opción 2: Angular CLI

```bash
# Requiere Node 18+ y Angular CLI 17
npm install --legacy-peer-deps
ng serve

# Acceder en: http://localhost:4200
```

### Opción 3: Build de producción

```bash
npm run build:prod
# Archivos generados en /dist/mutant-detector
```

---

## 🎮 Uso de la aplicación

1. Selecciona el **tamaño de la matriz** (4x4 a 8x8)
2. Ingresa cada fila con letras **A, T, C, G**
3. Presiona **Analizar ADN**
4. Observa el resultado:
   - Las celdas que forman secuencias se **iluminan en verde**
   - Se muestra el tipo y cantidad de secuencias encontradas
   - Badge en el header indica si es **MUTANTE** o **HUMANO**

### Ejemplos incluidos:
- 🧬 **Mutante (ejemplo doc)** — Caso del documento oficial
- 👤 **Humano** — ADN sin suficientes secuencias
- 🧬 **Mutante (vertical)** — Secuencias verticales

---

## 📂 Estructura del Proyecto

```
mutant-detector/
├── src/
│   ├── app/
│   │   ├── app.module.ts
│   │   ├── app.component.ts
│   │   ├── services/
│   │   │   └── mutant.service.ts       ← Algoritmo isMutant()
│   │   └── components/
│   │       └── dna-detector/
│   │           ├── dna-detector.component.ts
│   │           ├── dna-detector.component.html
│   │           └── dna-detector.component.scss
│   ├── styles.scss
│   ├── index.html
│   └── main.ts
├── Dockerfile                           ← Multi-stage build
├── docker-compose.yml
├── nginx.conf                           ← SPA routing config
├── angular.json
├── package.json
└── README.md
```

---

## 🛠 Tecnologías

- **Angular 17** con Reactive Forms
- **TypeScript 5.2**
- **RxJS 7.8**
- **SCSS** con variables CSS
- **Nginx Alpine** para producción
- **Docker & Docker Compose**
- Tipografías: **Orbitron** + **Rajdhani** (Google Fonts)

---

## ✅ Casos de prueba

```typescript
// Mutante: 2 secuencias (AAAA horizontal + CCCC horizontal)
isMutant(["ATGCGA","CAGTGC","TTATGT","AGAAGG","CCCCTA","TCACTG"]) // true

// Humano: solo 1 secuencia
isMutant(["ATGCGA","CAGTGC","TTATTT","AGACGG","GCGTCA","TCACTG"]) // false

// Mutante: secuencias vertical + horizontal
isMutant(["ATGCGA","ATGTGC","ATTATG","ATAAGG","CCCCTA","TCACTG"]) // true
```
